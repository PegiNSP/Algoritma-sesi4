public class Ulang5 {
    
    public static void main (String []args){
        System.out.println("5. ");
        for (int i = 1; i <= 4; i++) {
            String huruf = "A";
            for (int j = 1; j <= 4; j++) {
                System.out.print(huruf + " ");
                if (huruf == "A") {
                    huruf = "B";
                } else {
                    huruf = "A";
                }
            }
            System.out.println("");
        }
    }
}