public class Ulang3{

    public static void main (String[]args){
        int inisialisasi=7;
        int param1=0, param2=0, temp=0;
    
    for(int i=1;i<=inisialisasi;i++){
        if(param1 < i && i==1){
            System.out.print(i+",");
            param1=i;
            }
        if(param2 < param1){
            temp=param1+param2;
            System.out.print(temp+",");
            param2=temp;           
            }
        if(i>2){
            temp=param1+param2;
            System.out.print(temp+",");
            param1=param2;      
            param2=temp;        
            }
        }
    }
    }    
    
    
    
    