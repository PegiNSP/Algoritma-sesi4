public class Ulang6{

    public static void main (String[]args){
        System.out.println("6. ");
        for (int i = 1; i <= 4; i++) {
            String huruf = "A";
            for (int j = 4; j >= i; j--) {
                System.out.print(huruf + " ");
                if (huruf == "A") {
                    huruf = "B";
                } else {
                    huruf = "A";
                }
            }
            System.out.println("");
        }
    }
}