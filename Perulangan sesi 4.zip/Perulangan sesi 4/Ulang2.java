public class Ulang2 {
    
    public static void main(String[] args){
        for (int i=24; i>=12; i-=2){
            System.out.print(i + " ");
        }

    }
}
